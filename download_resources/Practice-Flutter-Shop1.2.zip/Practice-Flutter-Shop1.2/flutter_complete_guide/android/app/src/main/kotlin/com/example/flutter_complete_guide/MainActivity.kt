package com.example.flutter_complete_guide

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
