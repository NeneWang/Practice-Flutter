package com.example.meals

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
