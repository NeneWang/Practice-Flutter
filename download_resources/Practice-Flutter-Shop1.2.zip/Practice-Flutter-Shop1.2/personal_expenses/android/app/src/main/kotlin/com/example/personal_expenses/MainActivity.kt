package com.example.personal_expenses

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
